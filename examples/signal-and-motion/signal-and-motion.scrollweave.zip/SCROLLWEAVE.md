# 当前 ScrollWeave 连接

此文件由运行中的编辑器更新。作品：E:\ScrollWeaveProjects\Signal-and-Motion-v2

素材目录：E:\ScrollWeaveProjects\Signal-and-Motion-v2\assets

MCP（Streamable HTTP）：http://127.0.0.1:4100/mcp

Codex：codex mcp add scrollweave --url http://127.0.0.1:4100/mcp

编辑器源码：E:\web-animation-editor。请在作品目录生成素材。服务运行时连接才有效；项目包中的旧地址以本文件为准。
