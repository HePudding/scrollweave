# ScrollWeave 作品目录

连接地址以本目录 SCROLLWEAVE.md 为准，它在服务启动时更新。

这里是作品，不是编辑器源码。只把 PNG、JPEG、WebP、SVG、H.264/AAC MP4 或 VP8/VP9 WebM 素材写入 assets/。先写 .tmp，再重命名完成。编辑器自动监听；不需要改 JSON 或粘贴 base64。SVG 使用呈现属性，脚本、事件、外部引用、CSS 与内置动画会被清理。

MCP: http://127.0.0.1:4100/mcp （本机 Streamable HTTP；服务运行时有效）
Codex: codex mcp add scrollweave --url http://127.0.0.1:4100/mcp

先调用 workspace_info、read_project、list_assets；写文件后 wait_for_asset({path:"assets/name.svg"})；通过 insert_asset / edit_project 修改时间线。所有时间是秒；关键帧使用源时钟 sourceIn+(播放头-start)*speed。带最新 expectedRevision，冲突先重新读取，不盲目重试。多条命令一次事务、一次撤销。

默认导入仅入库。删除片段不删源文件。外部素材更新不进入时间线撤销；不要覆盖 project.scrollweave.json、缓存或 exports。替换素材先 inspect_asset 查看引用。复合素材共享内容，compound.independent 创建独立副本。保存 save_project，交付 export_html。图片/SVG 单 HTML；视频 HTML + assets ZIP。源代码目录：E:\web-animation-editor。
